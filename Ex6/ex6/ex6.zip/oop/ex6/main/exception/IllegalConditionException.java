package oop.ex6.main.exception;

public class IllegalConditionException extends GeneralException {
    public IllegalConditionException(String msg) {
        super(msg);
    }
}
