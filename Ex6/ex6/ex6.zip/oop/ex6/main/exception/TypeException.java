package oop.ex6.main.exception;

public class TypeException extends GeneralException{
    public TypeException(String msg) {
        super(msg);
    }
}
