package oop.ex6.main.exception;

public class IllegalSyntaxException extends GeneralException{
    public IllegalSyntaxException(String msg) {
        super(msg);
    }
}
