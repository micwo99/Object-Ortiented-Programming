package oop.ex6.main.exception;

public class VarInitializedException extends GeneralException{
    public VarInitializedException(String msg) {
        super(msg);
    }
}
