package oop.ex6.main.exception;

public class ReturnErrorException extends GeneralException{
    public ReturnErrorException(String msg) {
        super(msg);
    }
}
