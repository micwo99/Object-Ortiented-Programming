package oop.ex6.main.exception;

public class BracketException extends GeneralException {
    public BracketException(String msg) {
        super(msg);
    }
}
