package oop.ex6.main.exception;

public class MethodException extends GeneralException{
    public MethodException(String msg) {
        super(msg);
    }
}
