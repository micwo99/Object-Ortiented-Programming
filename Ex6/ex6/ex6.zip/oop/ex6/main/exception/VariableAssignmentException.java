package oop.ex6.main.exception;

public class VariableAssignmentException extends GeneralException{
    public VariableAssignmentException(String msg) {
        super(msg);
    }
}
