package oop.ex6.main.exception;

public class CommentException extends GeneralException{
    public CommentException(String msg) {
        super(msg);
    }
}
